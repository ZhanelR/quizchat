export const Answer = {
    answerId: 1, 
    title: '', 
    isCorrect: false, 
}