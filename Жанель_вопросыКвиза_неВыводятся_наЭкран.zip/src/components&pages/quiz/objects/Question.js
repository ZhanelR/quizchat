export const Question = {
    questionId: 0, 
    title: '', 
    answers: [], 
}