export const User = {
    userId: '', 
    userAva: '', 
    userName: '', 
    points: 0, 
  };