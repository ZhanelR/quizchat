import {useState, useRef} from "react"
import { useDispatch } from "react-redux";
import {sendMessage} from "../../redux/actions/chat/actionChat";

function Chat() {
    const [messages, setMessages] = useState([]);
    const dispatch = useDispatch();
    const inputMessage = useRef();
  
    function scrollToBottom() {
      const chatContainer = document.getElementById('chat-container');
      chatContainer.scrollTop = chatContainer.scrollHeight;
    }
  
    function handleNewMessage() {
      const message = inputMessage.current.value;
      dispatch(sendMessage(message));
    }
  
    return (
      <div className="chat-container" id="chat-container">
        <ul className="chat-list">
          {messages.map(message => (
            <li key={message.id} className="chat-message">
              <img className="user-avatar" src={message.userAva} alt={message.userName} />
              <div>
                <span className="user-name">{message.userName}</span>
                <span className="message-text">{message.text}</span>
              </div>
            </li>
          ))}
        </ul>
          <input type="text" ref={inputMessage} />
          <button onClick={() => handleNewMessage()}>Send</button>
       
      </div>
    );
  }

  export default Chat;
