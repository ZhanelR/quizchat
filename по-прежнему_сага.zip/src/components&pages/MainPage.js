import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Chat from "./Chat/Chat"
import { fetchMessages, sendMessage } from "../redux/actions/chat/actionChat"

function MainPage() {
  const dispatch = useDispatch();
  const messages = useSelector((state) => state.chat.messages);
  const isLoading = useSelector((state) => state.chat.isLoading);
  const error = useSelector((state) => state.chat.error);

  useEffect(() => {
    dispatch(fetchMessages());
  }, [dispatch]);

  function handleSendMessage(event) {
    event.preventDefault();
    const text = event.target.elements.message.value.trim();
    if (text) {
      dispatch(sendMessage(text));
      event.target.reset();
    }
  }

  return (
   <Chat />
  );
}

export default MainPage;
