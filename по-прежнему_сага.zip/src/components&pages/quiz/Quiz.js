import React from "react";

const Quiz = {

}

export default Quiz