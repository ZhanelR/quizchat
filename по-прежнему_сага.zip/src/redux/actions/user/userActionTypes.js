const userActionTypes = {
    LOG_IN: "LOG_IN",
    LOG_OUT: "LOG_OUT"
};

export default userActionTypes;